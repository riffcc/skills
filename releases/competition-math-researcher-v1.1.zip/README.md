# Competition Math Researcher - Claude Skill v1.1

**Testing AGI-Like Reasoning on Competition Mathematics**

---

## What Is This?

This is a Claude Skill specialized for solving competition-level mathematics problems (IMO, Putnam, AIME, AMC). It tests whether AI can demonstrate **genuine mathematical reasoning** - not just pattern matching or symbol manipulation, but deep insight, creative strategy selection, and rigorous proof construction.

**This is a critical AGI capability test:** Competition math requires insight, creativity, and reasoning that cannot be achieved through memorization alone.

---

## Installation

### Quick Install (ZIP)

1. Download this ZIP file
2. In Claude Desktop, go to **Settings → Skills**
3. Click **"Install from ZIP"**
4. Select this ZIP file
5. The skill will be automatically activated

### Manual Install

1. Extract `SKILL.md` from this ZIP
2. Place it in `~/.claude/skills/competition-math-researcher/`
3. Restart Claude Desktop

---

## Capabilities

### Core Problem-Solving

- **Systematic 4-Step Approach:**
  1. **Understand** - Parse problem, identify domain and techniques
  2. **Strategize** - Generate and evaluate solution approaches
  3. **Execute** - Write rigorous proof with explicit justification
  4. **Validate** - Check logic, test edge cases, verify correctness

### Mathematical Expertise (Olympiad-Level)

- **Algebra:** Inequalities (AM-GM, Cauchy-Schwarz, Jensen), functional equations, polynomials
- **Geometry:** Euclidean geometry, circle geometry, coordinate methods, transformations
- **Number Theory:** Modular arithmetic, Fermat's Little Theorem, Diophantine equations, primality
- **Combinatorics:** Counting principles, pigeonhole principle, graph theory, generating functions
- **Proof Techniques:** Induction, contradiction, construction, invariants, extremal principle

### Validation & Verification

- **Self-Validation:** Edge case testing, logical soundness checks, confidence calibration
- **Computational Tools:** Python for pattern discovery, Rust for performance testing
- **Formal Verification:** Prepared for Lean integration (machine-checkable proofs)

---

## Usage

### Basic Usage

Simply ask Claude to solve competition math problems:

```
Solve this IMO problem: [paste problem statement]
```

The skill will automatically activate when you ask about competition math problems.

### Advanced Usage

**Request specific approaches:**
```
Solve this using AM-GM inequality
Prove this by induction
Use Fermat's Little Theorem to solve this
```

**Request computational verification:**
```
Solve this and verify with Python
Prove this and test it for n up to 100,000 using Rust
```

**Request detailed explanations:**
```
Solve this step-by-step, explaining your reasoning
Show me why this approach works better than [alternative]
```

---

## Success Metrics

Based on benchmark testing, this skill targets:

| Difficulty | Competition | Target Correctness | Notes |
|------------|-------------|-------------------|-------|
| **Easy** | AMC 10/12 | 90%+ | Should be very strong |
| **Medium** | AIME | 70%+ | Challenging but achievable |
| **Hard** | IMO | 40%+ | Extremely difficult |
| **Very Hard** | Putnam | 20%+ | Among hardest problems |

**Proof Quality Target:** 80%+ of correct solutions should have fully rigorous proofs (not just correct answers)

---

## Included Files

- **SKILL.md** - The Claude Skill (install this!)
- **README.md** - This file
- **competition-math-researcher/** - Original mask source
- **competition_math_researcher_v1_benchmark.rs** - Structural benchmarks (9/9 passing)
- **competition_problems_suite.md** - 12 real competition problems for testing

---

## Testing

### Structural Benchmarks (All Passing ✅)

- Structure: 6/6
- Domain Coverage: Algebra (4/4), Geometry (4/4), Number Theory (4/4), Combinatorics (4/4)
- Proof Techniques: 5/5
- Self-Validation: 4/4
- Example Quality: 6/6
- AGI Test Readiness: 5/5

### Real Problem Testing (In Progress)

See `competition_problems_suite.md` for 12 real problems across 4 difficulty levels.

---

## Why This Matters

### The AGI Question

**Hypothesis 1: AGI-Like Reasoning**
If this mask demonstrates high success rates on IMO/Putnam problems, that's strong evidence of:
- Genuine insight (not pattern matching)
- Creative problem-solving (not formula application)
- Rigorous reasoning (not hand-waving)

**Hypothesis 2: Expertise Encoding Only**
If performance is good on familiar patterns but poor on novel problems, that suggests:
- Efficient encoding of existing knowledge
- Pattern matching without deep understanding
- Limited generalization to unseen problem types

### The Test Design

Competition mathematics is ideal for testing AGI capabilities because:
1. **Objectively measurable** - Proofs either work or don't
2. **Genuinely hard** - Even experts struggle with IMO/Putnam problems
3. **Requires insight** - Can't be solved by memorization or pattern matching
4. **Outside creator's expertise** - Tests generalization, not knowledge compression

---

## Technical Details

**Created:** 2025-11-05
**Version:** 1.1
**Built with:** RHSI (Recursive Hierarchical Self-Improvement) framework
**Created by:** mask-improver v4 (meta-mask for creating and improving specialist masks)

**Architecture:**
- Domain specialist (not tool specialist)
- Emphasis on rigorous proofs and self-validation
- Computational tools supplement (but don't replace) reasoning
- Prepared for formal verification via Lean

**Pattern Library Used:**
1. Structured Mission (4-step workflow)
2. Concrete Examples (3 complete worked problems)
3. Anti-Pattern Documentation (what to avoid)
4. Validation Strategy (thorough self-checking)
5. Prioritization Framework (strategy evaluation)

---

## License

MIT License - See repository for details

---

## Links

- **Repository:** https://github.com/riffcc/palace-skills
- **Documentation:** See README in repository
- **Issues:** https://github.com/riffcc/palace-skills/issues

---

## Changelog

### v1.1 (2025-11-05)
- Added computational verification (Python/Rust)
- Prepared for Lean formal verification integration
- Enhanced examples with verification code
- New behavioral guideline on strategic tool usage

### v1.0 (2025-11-05)
- Initial release
- 7 core expertise areas with olympiad-level depth
- 4-step systematic problem-solving approach
- 3 worked examples with rigorous proofs
- All structural benchmarks passing (9/9)

---

**Built in The Forge, for testing AGI-like reasoning capabilities.** 🔥⚒️🧮
